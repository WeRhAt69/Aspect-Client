package cc.silk.module.modules.misc;

import cc.silk.event.impl.network.PacketEvent;
import cc.silk.event.impl.player.TickEvent;
import cc.silk.event.types.TransferOrder;
import cc.silk.mixin.HandledScreenAccessor;
import cc.silk.module.Category;
import cc.silk.module.Module;
import cc.silk.module.setting.BooleanSetting;
import cc.silk.module.setting.NumberSetting;
import cc.silk.module.setting.RangeSetting;
import cc.silk.utils.math.TimerUtil;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

public final class HoverTotem extends Module {
    public static final RangeSetting delayMS = new RangeSetting("Delay (MS)", 1, 1000, 200, 400, 0.5);
    public static final BooleanSetting ignoreOffhand = new BooleanSetting("Ignore Offhand", false);
    public static final BooleanSetting autoOpenGUI = new BooleanSetting("Auto Open GUI", true);
    private final NumberSetting normalBaseDelay = new NumberSetting("Base Delay", 50, 1000, 200, 1);
    private final NumberSetting normalVariation = new NumberSetting("Variation", 10, 1000, 150, 1);
    private final NumberSetting normalSDThreshold = new NumberSetting("SD Threshold", 1, 500, 80, 1);
    private final TimerUtil timer = new TimerUtil();
    private final Random random = new Random();
    private final List<Long> recentIntervals = new ArrayList<>();
    private final List<Double> recentStandardDeviations = new ArrayList<>();
    private int swapCount = 0;
    private boolean preventClose = false;
    private boolean needsTotemSetup = false;

    public HoverTotem() {
        super("Hover Totem", "Puts a totem in your offhand and hotbar once hovered", -1, Category.MISC);
        this.addSettings(delayMS, ignoreOffhand, autoOpenGUI, normalBaseDelay, normalVariation, normalSDThreshold);
    }

    @EventHandler
    private void onTickEvent(TickEvent event) {
        if (isNull()) return;
        totemHandler();
        if (preventClose && needsTotemSetup && hasTotemSetup() && mc.currentScreen instanceof InventoryScreen) {
            preventClose = false;
            needsTotemSetup = false;
            mc.player.closeHandledScreen();
        }
    }

    @EventHandler
    private void onPacketEvent(PacketEvent event) {
        if (isNull()) return;
        if (event.getOrder() == TransferOrder.RECEIVE) {
            if (event.getPacket() instanceof EntityStatusS2CPacket packet) {
                if (packet.getStatus() == 35) {
                    Entity entity = packet.getEntity(mc.world);
                    if (entity != null && entity.equals(mc.player)) {
                        if (!hasTotemSetup()) {
                            preventClose = true;
                            needsTotemSetup = true;
                            if (autoOpenGUI.getValue()) {
                                mc.execute(() -> {
                                    if (mc.currentScreen == null) {
                                        mc.setScreen(new InventoryScreen(mc.player));
                                    }
                                });
                            }
                        } else {
                            preventClose = false;
                            needsTotemSetup = false;
                        }
                    }
                }
            }
        }
        if (event.getOrder() == TransferOrder.SEND) {
            if (event.getPacket().getClass().getSimpleName().contains("CloseHandledScreen")) {
                if (preventClose) {
                    if (!hasTotemSetup()) {
                        event.setCancelled(true);
                        if (autoOpenGUI.getValue()) {
                            mc.execute(() -> {
                                if (!(mc.currentScreen instanceof InventoryScreen)) {
                                    mc.setScreen(new InventoryScreen(mc.player));
                                }
                            });
                        }
                    } else {
                        preventClose = false;
                    }
                }
            }
        }
    }

    private boolean hasTotemSetup() {
        if (isNull()) return true;
        ItemStack offhandItem = mc.player.getOffHandStack();
        boolean hasOffhandTotem = offhandItem.getItem() == Items.TOTEM_OF_UNDYING || ignoreOffhand.getValue();
        boolean hasHotbarTotem = hasTotemInHotbar();
        return hasOffhandTotem && hasHotbarTotem;
    }

    private void totemHandler() {
        if (isNull()) return;
        if (!(mc.currentScreen instanceof InventoryScreen inv)) return;
        Slot focusedSlot = ((HandledScreenAccessor) inv).getFocusedSlot();
        if (focusedSlot == null) return;
        ItemStack focusedItemStack = focusedSlot.getStack();
        if (focusedItemStack.getItem() != Items.TOTEM_OF_UNDYING) return;
        if (focusedSlot.getIndex() < 9) return;
        ItemStack offhandItem = mc.player.getOffHandStack();
        boolean needsOffhand = offhandItem.isEmpty() || (offhandItem.getItem() != Items.TOTEM_OF_UNDYING && !ignoreOffhand.getValue());
        boolean needsHotbar = !hasTotemInHotbar();
        if (!needsOffhand && !needsHotbar) return;
        long delay = generateNormalModeDelay();
        if (timer.hasElapsedTime(delay, true)) {
            assert mc.player != null;
            assert mc.interactionManager != null;
            if (needsOffhand) {
                mc.interactionManager.clickSlot(
                        mc.player.currentScreenHandler.syncId,
                        focusedSlot.getIndex(),
                        40,
                        SlotActionType.SWAP,
                        mc.player);
            } else {
                mc.interactionManager.clickSlot(
                        mc.player.currentScreenHandler.syncId,
                        focusedSlot.getIndex(),
                        0,
                        SlotActionType.QUICK_MOVE,
                        mc.player);
            }
        }
    }

    private boolean hasTotemInHotbar() {
        if (isNull()) return false;
        return IntStream.range(0, 9)
                .mapToObj(i -> mc.player.getInventory().getStack(i))
                .anyMatch(stack -> stack.getItem() == Items.TOTEM_OF_UNDYING);
    }

    private long generateNormalModeDelay() {
        swapCount++;
        long baseDelay = normalBaseDelay.getValueInt();
        int variation = normalVariation.getValueInt();
        double sdThreshold = normalSDThreshold.getValue();
        long noise = (long) ((random.nextDouble() - 0.5) * variation * 2);
        noise += (System.currentTimeMillis() % 97) - 48;
        if (swapCount % (3 + random.nextInt(3)) == 0) {
            noise += random.nextBoolean() ? random.nextInt(variation) : -random.nextInt(variation / 2);
        }
        double recentSD = recentStandardDeviations.isEmpty() ? 0 : recentStandardDeviations.getLast();
        if (recentSD < sdThreshold * 0.75) {
            noise += (long) ((random.nextDouble() - 0.5) * (variation * 1.5));
        }
        long finalDelay = Math.max(80, Math.min(2000, baseDelay + noise));
        recentIntervals.add(finalDelay);
        if (recentIntervals.size() > 10) recentIntervals.removeFirst();
        updateStandardDeviationTracking();
        return finalDelay;
    }

    private double calculateDoubleAverage(List<Long> list) {
        return list.stream().mapToDouble(Long::doubleValue).average().orElse(0);
    }

    private double calculateAverage(List<Double> list) {
        return list.stream().mapToDouble(Double::doubleValue).average().orElse(0);
    }

    private void updateStandardDeviationTracking() {
        if (recentIntervals.size() < 2) return;
        double mean = calculateDoubleAverage(recentIntervals);
        double variance = 0.0;
        for (long interval : recentIntervals) {
            variance += Math.pow(interval - mean, 2);
        }
        variance /= recentIntervals.size();
        double stdDev = Math.sqrt(variance);
        recentStandardDeviations.add(stdDev);
        if (recentStandardDeviations.size() > 10) recentStandardDeviations.removeFirst();
    }

    @Override
    public void onEnable() {
        timer.reset();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        timer.reset();
        preventClose = false;
        needsTotemSetup = false;
        super.onDisable();
    }
}
