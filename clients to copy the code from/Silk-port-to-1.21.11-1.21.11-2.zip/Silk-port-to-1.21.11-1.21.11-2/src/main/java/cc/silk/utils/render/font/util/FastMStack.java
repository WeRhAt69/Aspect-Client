package cc.silk.utils.render.font.util;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.client.util.math.MatrixStack;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionfc;

/**
 * A reimplementation of {@link MatrixStack}, containing a few optimizations.
 */
public class FastMStack extends MatrixStack {

    private final ObjectArrayList<Entry> fEntries = new ObjectArrayList<>(8);
    private Entry top;

    public FastMStack() {
        fEntries.add(top = new Entry(new Matrix4f(), new Matrix3f()));
    }

    @Override
    public void translate(float x, float y, float z) {
        top.positionMatrix.translate(x, y, z);
    }

    @Override
    public void scale(float x, float y, float z) {
        top.positionMatrix.scale(x, y, z);
        if (x == y && y == z) {
            if (x != 0) {
                top.normalMatrix.scale(Math.signum(x));
            }
            return;
        }
        float inverseX = 1.0f / x;
        float inverseY = 1.0f / y;
        float inverseZ = 1.0f / z;
        float scalar = (float) (1f / Math.cbrt(inverseX * inverseY * inverseZ));
        top.normalMatrix.scale(scalar * inverseX, scalar * inverseY, scalar * inverseZ);
    }

    @Override
    public void multiply(Quaternionfc quaternion) {
        top.positionMatrix.rotate(quaternion);
        top.normalMatrix.rotate(quaternion);
    }

    @Override
    public void multiply(Quaternionfc quaternion, float originX, float originY, float originZ) {
        top.positionMatrix.rotateAround(quaternion, originX, originY, originZ);
        top.normalMatrix.rotate(quaternion);
    }

    @Override
    public void multiplyPositionMatrix(Matrix4fc matrix) {
        top.positionMatrix.mul(matrix);
    }

    @Override
    public void push() {
        fEntries.add(top = new Entry(new Matrix4f(top.positionMatrix), new Matrix3f(top.normalMatrix)));
    }

    @Override
    public void pop() {
        if (fEntries.size() == 1) {
            throw new IllegalStateException("Trying to pop an empty stack");
        }
        fEntries.pop();
        top = fEntries.top();
    }

    @Override
    public MatrixStack.Entry peek() {
        // Create a new Entry and populate it with current matrices
        MatrixStack.Entry entry = new MatrixStack.Entry();
        entry.getPositionMatrix().set(top.positionMatrix);
        entry.getNormalMatrix().set(top.normalMatrix);
        return entry;
    }

    @Override
    public boolean isEmpty() {
        return fEntries.size() == 1;
    }

    @Override
    public void loadIdentity() {
        top.positionMatrix.identity();
        top.normalMatrix.identity();
    }

    record Entry(Matrix4f positionMatrix, Matrix3f normalMatrix) {

        @Override
        public @NotNull String toString() {
            return "Entry[" +
                    "positionMatrix=" + positionMatrix + ", " +
                    "normalMatrix=" + normalMatrix + ']';
        }

    }
}
